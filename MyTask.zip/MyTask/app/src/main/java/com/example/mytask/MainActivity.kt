package com.example.mytask

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mytask.adapter.TaskAdapter
import com.example.mytask.databinding.ActivityMainBinding
import com.example.mytask.model.TaskDatabase
import com.example.mytask.model.TaskRepository
import com.example.mytask.ui.AddTaskDialogFragment
import com.example.mytask.ui.TaskViewModel
import com.example.mytask.ui.TaskViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val viewModel: TaskViewModel by viewModels {
        TaskViewModelFactory(
            TaskRepository(
                TaskDatabase.getDatabase(application).taskDao()
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Hook up the toolbar
        setSupportActionBar(binding.topAppBar)

        // 1) Set up RecyclerView & Adapter
        val adapter = TaskAdapter(
            this,
            onEdit = { task ->
                AddTaskDialogFragment(task) { updated ->
                    viewModel.update(updated)
                }.show(supportFragmentManager, "EditTask")
            },
            onDelete = { task ->
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.delete_task))
                    .setMessage(getString(R.string.confirm_delete, task.title))
                    .setPositiveButton(getString(R.string.delete)) { _, _ ->
                        viewModel.delete(task)
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            },
            onToggle = { toggled ->
                viewModel.update(toggled)
            }
        )

        binding.recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewTasks.adapter = adapter

        // 2) Observe the live data and toggle empty‑state view
        viewModel.allTasks.observe(this, Observer { tasks ->
            adapter.submitList(tasks)
            // If zero tasks, show the "No tasks yet" message, else show the list
            binding.textViewEmpty.visibility =
                if (tasks.isEmpty()) View.VISIBLE else View.GONE
        })

        // 3) FAB opens the Add‑Task dialog
        binding.fabAddTask.setOnClickListener {
            AddTaskDialogFragment(null) { newTask ->
                Toast.makeText(this, "Got task: ${newTask.title}", Toast.LENGTH_SHORT).show()
                viewModel.insert(newTask)
            }.show(supportFragmentManager, "AddTask")
        }
    }
}
