package com.example.mytask.ui

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.example.mytask.R
import com.example.mytask.databinding.DialogAddTaskBinding
import com.example.mytask.model.Priority
import com.example.mytask.model.Task
import java.text.SimpleDateFormat
import java.util.*

class AddTaskDialogFragment(
    private val existing: Task? = null,
    private val onSave: (Task) -> Unit
) : DialogFragment() {

    private var _binding: DialogAddTaskBinding? = null
    private val b get() = _binding!!
    private val cal = Calendar.getInstance()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAddTaskBinding.inflate(LayoutInflater.from(context))

        // If editing, pre‑fill fields
        existing?.let { task ->
            b.editTextTitle.setText(task.title)
            b.editTextDescription.setText(task.description)
            b.editTextDate.setText(task.dueDate)
            b.spinnerPriority.setSelection(task.priority.ordinal)
        }

        // Date picker
        b.editTextDate.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                { _, year, month, dayOfMonth ->
                    cal.set(year, month, dayOfMonth)
                    val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                    b.editTextDate.setText(fmt.format(cal.time))
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // Load spinner from resources
        b.spinnerPriority.adapter = ArrayAdapter.createFromResource(
            requireContext(),
            R.array.priority_array,
            android.R.layout.simple_spinner_dropdown_item
        )

        // Build dialog
        return AlertDialog.Builder(requireContext())
            .setView(b.root)
            .setTitle(
                if (existing == null)
                    getString(R.string.add_task)
                else
                    getString(R.string.edit_task)
            )
            .setPositiveButton(getString(R.string.save_task), null)  // override later
            .setNegativeButton(android.R.string.cancel, null)
            .create()
    }

    override fun onStart() {
        super.onStart()
        // Intercept the Save button to perform validation
        val dialog = dialog as AlertDialog
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val title = b.editTextTitle.text.toString().trim()
            val desc  = b.editTextDescription.text.toString().trim()
            val date  = b.editTextDate.text.toString().trim()

            if (title.isEmpty() || date.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.error_empty_fields),
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                // All good, build the Task and invoke callback
                val newTask = Task(
                    id          = existing?.id ?: 0,
                    title       = title,
                    description = desc,
                    dueDate     = date,
                    priority    = Priority.values()[b.spinnerPriority.selectedItemPosition],
                    isCompleted = existing?.isCompleted ?: false
                )
                onSave(newTask)
                dialog.dismiss()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
