package com.example.mytask.adapter

import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mytask.databinding.ItemTaskBinding
import com.example.mytask.model.Task

class TaskAdapter(
    private val context: Context,
    private val onEdit: (Task) -> Unit,
    private val onDelete: (Task) -> Unit,
    private val onToggle: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    private var taskList = listOf<Task>()

    inner class TaskViewHolder(val b: ItemTaskBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(LayoutInflater.from(context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        val b = holder.b

        b.textViewTitle.text = task.title
        b.textViewDescription.text = task.description
        b.textViewDate.text = task.dueDate
        b.textViewPriority.text = task.priority.name
            .replaceFirstChar { char -> char.uppercase() }
        b.checkBoxCompleted.isChecked = task.isCompleted

        b.textViewTitle.paintFlags = if (task.isCompleted) {
            b.textViewTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        } else {
            b.textViewTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
        }

        b.checkBoxCompleted.setOnClickListener {
            onToggle(task.copy(isCompleted = b.checkBoxCompleted.isChecked))
        }

        b.buttonEdit.setOnClickListener { onEdit(task) }
        b.buttonDelete.setOnClickListener { onDelete(task) }
    }

    override fun getItemCount(): Int = taskList.size

    fun submitList(newList: List<Task>) {
        taskList = newList
        notifyDataSetChanged()
    }
}